require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

const authRoutes = require("./routes/auth");
const orderRoutes = require("./routes/orders");
const carrierRoutes = require("./routes/carriers");
const driverRoutes = require("./routes/drivers");
const shipperRoutes = require("./routes/shippers");
const documentRoutes = require("./routes/documents");
const invoiceRoutes = require("./routes/invoices");
const paymentRoutes = require("./routes/payments");
const reportRoutes = require("./routes/reports");
const teamRoutes = require("./routes/team");

const app = express();

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || "*" }));
app.use(express.json());
app.use(morgan("dev"));

app.get("/api/health", (req, res) => res.json({ status: "ok", service: "Eminent Ventures TMS API" }));

app.use("/api/auth", authRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/carriers", carrierRoutes);
app.use("/api/drivers", driverRoutes);
app.use("/api/shippers", shipperRoutes);
app.use("/api/documents", documentRoutes);
app.use("/api/invoices", invoiceRoutes);
app.use("/api/payments", paymentRoutes);
app.use("/api/reports", reportRoutes);
app.use("/api/team", teamRoutes);

app.use((req, res) => res.status(404).json({ error: "Route not found" }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`Eminent Ventures TMS API running on port ${PORT}`));
