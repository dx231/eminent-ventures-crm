const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { rows } = await pool.query(
    `SELECT d.*, c.name AS carrier_name FROM drivers d
     LEFT JOIN carriers c ON c.id = d.carrier_id ORDER BY d.name`
  );
  res.json(rows);
});

router.post("/", requireRole("admin", "dispatcher"), async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO drivers (carrier_id, name, phone, truck_number, trailer_type, availability, location_label)
     VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *`,
    [b.carrierId, b.name, b.phone, b.truckNumber, b.trailerType || "Open", b.availability || "Available", b.locationLabel]
  );
  res.status(201).json(rows[0]);
});

router.patch("/:id/status", requireRole("admin", "dispatcher"), async (req, res) => {
  const { availability, locationLabel } = req.body;
  const { rows } = await pool.query(
    `UPDATE drivers SET availability = COALESCE($1, availability), location_label = COALESCE($2, location_label)
     WHERE id = $3 RETURNING *`,
    [availability, locationLabel, req.params.id]
  );
  res.json(rows[0]);
});

module.exports = router;
