const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// GET /api/orders?status=&customer=&carrier=&dispatcher=&q=
router.get("/", async (req, res) => {
  const { status, q } = req.query;
  const clauses = [];
  const params = [];

  if (status && status !== "All") {
    params.push(status);
    clauses.push(`status = $${params.length}`);
  }
  if (q) {
    params.push(`%${q}%`);
    clauses.push(`(order_number ILIKE $${params.length} OR vin ILIKE $${params.length})`);
  }
  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";

  try {
    const { rows } = await pool.query(
      `SELECT * FROM orders ${where} ORDER BY created_at DESC LIMIT 200`,
      params
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to fetch orders" });
  }
});

// GET /api/orders/:id
router.get("/:id", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM orders WHERE id = $1", [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: "Order not found" });
  res.json(rows[0]);
});

// POST /api/orders  — create order (profit is auto-computed by the DB)
router.post("/", requireRole("admin", "dispatcher", "sales_agent"), async (req, res) => {
  const b = req.body;
  try {
    const orderNumber = `EV-${Math.floor(10000 + Math.random() * 89999)}`;
    const { rows } = await pool.query(
      `INSERT INTO orders (
        order_number, shipper_id, dispatcher_id,
        pickup_contact, pickup_phone, pickup_address, pickup_city, pickup_state, pickup_date,
        delivery_contact, delivery_phone, delivery_address, delivery_city, delivery_state, delivery_date,
        vehicle_year, vehicle_make, vehicle_model, vin, lot_number, vehicle_condition, transport_type,
        customer_pay, carrier_pay, deposit, status
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,'Available')
      RETURNING *`,
      [
        orderNumber, b.shipperId || null, req.user.id,
        b.pickupContact, b.pickupPhone, b.pickupAddress, b.pickupCity, b.pickupState, b.pickupDate,
        b.deliveryContact, b.deliveryPhone, b.deliveryAddress, b.deliveryCity, b.deliveryState, b.deliveryDate,
        b.vehicleYear, b.vehicleMake, b.vehicleModel, b.vin, b.lotNumber, b.vehicleCondition || "Running", b.transportType || "Open",
        b.customerPay || 0, b.carrierPay || 0, b.deposit || 0,
      ]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to create order" });
  }
});

// PATCH /api/orders/:id/status  { status }
router.patch("/:id/status", requireRole("admin", "dispatcher"), async (req, res) => {
  const { status } = req.body;
  try {
    const current = await pool.query("SELECT status FROM orders WHERE id = $1", [req.params.id]);
    if (!current.rows[0]) return res.status(404).json({ error: "Order not found" });

    const { rows } = await pool.query(
      "UPDATE orders SET status = $1, updated_at = now() WHERE id = $2 RETURNING *",
      [status, req.params.id]
    );
    await pool.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by)
       VALUES ($1,$2,$3,$4)`,
      [req.params.id, current.rows[0].status, status, req.user.id]
    );
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to update status" });
  }
});

// PATCH /api/orders/:id/assign  { carrierId, driverId, pickupEta, deliveryEta }
router.patch("/:id/assign", requireRole("admin", "dispatcher"), async (req, res) => {
  const { carrierId, driverId, pickupEta, deliveryEta } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE orders SET carrier_id = $1, driver_id = $2, pickup_eta = $3, delivery_eta = $4,
       status = 'Assigned', updated_at = now() WHERE id = $5 RETURNING *`,
      [carrierId, driverId || null, pickupEta, deliveryEta, req.params.id]
    );
    if (!rows[0]) return res.status(404).json({ error: "Order not found" });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to assign carrier" });
  }
});

module.exports = router;
