const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { status } = req.query;
  const clauses = [];
  const params = [];
  if (status && status !== "All") { params.push(status); clauses.push(`p.status = $${params.length}`); }
  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const { rows } = await pool.query(
    `SELECT p.*, o.order_number, c.name AS carrier_name FROM carrier_payments p
     JOIN orders o ON o.id = p.order_id
     LEFT JOIN carriers c ON c.id = p.carrier_id
     ${where} ORDER BY p.created_at DESC`, params
  );
  res.json(rows);
});

router.post("/", requireRole("admin", "dispatcher"), async (req, res) => {
  const { orderId, carrierId, amount } = req.body;
  const paymentNumber = `PAY-${Math.floor(1000 + Math.random() * 8999)}`;
  const { rows } = await pool.query(
    `INSERT INTO carrier_payments (payment_number, order_id, carrier_id, amount) VALUES ($1,$2,$3,$4) RETURNING *`,
    [paymentNumber, orderId, carrierId, amount]
  );
  res.status(201).json(rows[0]);
});

router.patch("/:id/pay", requireRole("admin", "dispatcher"), async (req, res) => {
  const { method } = req.body;
  const { rows } = await pool.query(
    `UPDATE carrier_payments SET status = 'Paid', method = $1, paid_at = now() WHERE id = $2 RETURNING *`,
    [method, req.params.id]
  );
  res.json(rows[0]);
});

module.exports = router;
