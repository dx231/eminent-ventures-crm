const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { status } = req.query;
  const clauses = [];
  const params = [];
  if (status && status !== "All") { params.push(status); clauses.push(`i.status = $${params.length}`); }
  const where = clauses.length ? `WHERE ${clauses.join(" AND ")}` : "";
  const { rows } = await pool.query(
    `SELECT i.*, o.order_number, s.name AS shipper_name FROM invoices i
     JOIN orders o ON o.id = i.order_id
     LEFT JOIN shippers s ON s.id = i.shipper_id
     ${where} ORDER BY i.created_at DESC`, params
  );
  res.json(rows);
});

router.post("/", requireRole("admin", "dispatcher"), async (req, res) => {
  const { orderId, shipperId, amount, dueDate } = req.body;
  const invoiceNumber = `INV-${Math.floor(1000 + Math.random() * 8999)}`;
  const { rows } = await pool.query(
    `INSERT INTO invoices (invoice_number, order_id, shipper_id, amount, due_date) VALUES ($1,$2,$3,$4,$5) RETURNING *`,
    [invoiceNumber, orderId, shipperId, amount, dueDate]
  );
  res.status(201).json(rows[0]);
});

router.patch("/:id/pay", requireRole("admin", "dispatcher"), async (req, res) => {
  const { method } = req.body;
  const { rows } = await pool.query(
    `UPDATE invoices SET status = 'Paid', method = $1, paid_at = now() WHERE id = $2 RETURNING *`,
    [method, req.params.id]
  );
  res.json(rows[0]);
});

module.exports = router;
