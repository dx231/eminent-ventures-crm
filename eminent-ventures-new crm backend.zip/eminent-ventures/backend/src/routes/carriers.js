const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM carriers WHERE active = TRUE ORDER BY name");
  res.json(rows);
});

router.get("/:id", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM carriers WHERE id = $1", [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: "Carrier not found" });
  res.json(rows[0]);
});

router.post("/", requireRole("admin", "dispatcher"), async (req, res) => {
  const b = req.body;
  const { rows } = await pool.query(
    `INSERT INTO carriers (name, mc_number, dot_number, phone, email, equipment_type)
     VALUES ($1,$2,$3,$4,$5,$6) RETURNING *`,
    [b.name, b.mcNumber, b.dotNumber, b.phone, b.email, b.equipmentType || "Open"]
  );
  res.status(201).json(rows[0]);
});

router.patch("/:id/documents", requireRole("admin", "dispatcher"), async (req, res) => {
  const { w9Uploaded, coiUploaded } = req.body;
  const { rows } = await pool.query(
    `UPDATE carriers SET w9_uploaded = COALESCE($1, w9_uploaded), coi_uploaded = COALESCE($2, coi_uploaded)
     WHERE id = $3 RETURNING *`,
    [w9Uploaded, coiUploaded, req.params.id]
  );
  res.json(rows[0]);
});

module.exports = router;
