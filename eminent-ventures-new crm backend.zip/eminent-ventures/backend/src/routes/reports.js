const express = require("express");
const pool = require("../db/pool");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// GET /api/reports/summary?from=&to=&customerId=&carrierId=&dispatcherId=
router.get("/summary", async (req, res) => {
  const { from, to, customerId, carrierId, dispatcherId } = req.query;
  const clauses = ["status <> 'Cancelled'"];
  const params = [];

  if (from) { params.push(from); clauses.push(`pickup_date >= $${params.length}`); }
  if (to) { params.push(to); clauses.push(`pickup_date <= $${params.length}`); }
  if (customerId) { params.push(customerId); clauses.push(`shipper_id = $${params.length}`); }
  if (carrierId) { params.push(carrierId); clauses.push(`carrier_id = $${params.length}`); }
  if (dispatcherId) { params.push(dispatcherId); clauses.push(`dispatcher_id = $${params.length}`); }

  const where = `WHERE ${clauses.join(" AND ")}`;

  const { rows } = await pool.query(
    `SELECT
       COUNT(*) FILTER (WHERE status = 'Delivered') AS completed,
       COALESCE(SUM(customer_pay), 0) AS revenue,
       COALESCE(SUM(carrier_pay), 0) AS carrier_pay,
       COALESCE(SUM(profit), 0) AS profit,
       COALESCE(AVG(profit), 0) AS avg_profit
     FROM orders ${where}`,
    params
  );
  res.json(rows[0]);
});

// GET /api/reports/by-dispatcher
router.get("/by-dispatcher", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM v_dispatcher_performance ORDER BY profit DESC");
  res.json(rows);
});

module.exports = router;
