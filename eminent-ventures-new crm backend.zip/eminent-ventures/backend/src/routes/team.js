const express = require("express");
const pool = require("../db/pool");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// GET /api/team/performance — per-agent booked/revenue/carrier pay/profit
router.get("/performance", async (req, res) => {
  const { rows } = await pool.query("SELECT * FROM v_dispatcher_performance ORDER BY profit DESC");
  res.json(rows);
});

// GET /api/team/goal — active team goal + progress
router.get("/goal", async (req, res) => {
  const goal = await pool.query(
    "SELECT * FROM team_goals WHERE CURRENT_DATE BETWEEN period_start AND period_end ORDER BY period_start DESC LIMIT 1"
  );
  if (!goal.rows[0]) return res.status(404).json({ error: "No active team goal" });

  const g = goal.rows[0];
  const profit = await pool.query(
    `SELECT COALESCE(SUM(profit), 0) AS total_profit FROM orders
     WHERE status <> 'Cancelled' AND pickup_date BETWEEN $1 AND $2`,
    [g.period_start, g.period_end]
  );
  const totalProfit = Number(profit.rows[0].total_profit);
  res.json({
    ...g,
    current_profit: totalProfit,
    remaining: Math.max(0, Number(g.target_amount) - totalProfit),
    percent_complete: Math.min(100, (totalProfit / Number(g.target_amount)) * 100),
  });
});

module.exports = router;
