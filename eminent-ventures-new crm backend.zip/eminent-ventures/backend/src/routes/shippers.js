const express = require("express");
const pool = require("../db/pool");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

router.get("/", async (req, res) => {
  const { rows } = await pool.query(`
    SELECT s.*, COUNT(o.id) AS order_count, COALESCE(SUM(o.customer_pay), 0) AS total_spend
    FROM shippers s
    LEFT JOIN orders o ON o.shipper_id = s.id AND o.status <> 'Cancelled'
    GROUP BY s.id ORDER BY total_spend DESC
  `);
  res.json(rows);
});

router.post("/", requireRole("admin", "dispatcher", "sales_agent"), async (req, res) => {
  const { name, email, phone, billingAddress } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO shippers (name, email, phone, billing_address) VALUES ($1,$2,$3,$4) RETURNING *`,
    [name, email, phone, billingAddress]
  );
  res.status(201).json(rows[0]);
});

module.exports = router;
