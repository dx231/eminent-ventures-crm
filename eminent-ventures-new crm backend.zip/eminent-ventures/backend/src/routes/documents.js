const express = require("express");
const pool = require("../db/pool");
const { requireAuth } = require("../middleware/auth");

const router = express.Router();
router.use(requireAuth);

// GET /api/documents?orderId=
router.get("/", async (req, res) => {
  const { orderId } = req.query;
  const { rows } = await pool.query(
    orderId ? "SELECT * FROM documents WHERE order_id = $1 ORDER BY generated_at DESC" : "SELECT * FROM documents ORDER BY generated_at DESC LIMIT 100",
    orderId ? [orderId] : []
  );
  res.json(rows);
});

// POST /api/documents/generate  { orderId, docType }
router.post("/generate", async (req, res) => {
  const { orderId, docType } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO documents (order_id, doc_type) VALUES ($1,$2) RETURNING *`,
    [orderId, docType]
  );
  res.status(201).json(rows[0]);
});

// POST /api/documents/:id/sign  { signedBy }
router.post("/:id/sign", async (req, res) => {
  const { signedBy } = req.body;
  if (!signedBy) return res.status(400).json({ error: "signedBy is required to e-sign" });
  const { rows } = await pool.query(
    `UPDATE documents SET signed = TRUE, signed_by = $1, signed_at = now() WHERE id = $2 RETURNING *`,
    [signedBy, req.params.id]
  );
  if (!rows[0]) return res.status(404).json({ error: "Document not found" });
  res.json(rows[0]);
});

module.exports = router;
