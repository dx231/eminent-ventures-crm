-- ============================================================
--  Eminent Ventures — Broker/Shipper TMS
--  Database Schema (PostgreSQL 14+)
-- ============================================================

CREATE TYPE user_role AS ENUM ('admin', 'dispatcher', 'sales_agent', 'shipper');
CREATE TYPE order_status AS ENUM ('Available', 'Assigned', 'Picked Up', 'In Transit', 'Delivered', 'Cancelled');
CREATE TYPE transport_type AS ENUM ('Open', 'Enclosed');
CREATE TYPE vehicle_condition AS ENUM ('Running', 'Inoperable');
CREATE TYPE payment_status AS ENUM ('Unpaid', 'Paid', 'Partial');
CREATE TYPE doc_type AS ENUM ('BOL', 'Dispatch Sheet', 'Rate Confirmation', 'Invoice', 'Proof of Delivery');
CREATE TYPE driver_availability AS ENUM ('Available', 'On Route', 'Off Duty');

-- ------------------------------------------------------------
-- Users & Auth
-- ------------------------------------------------------------
CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name       VARCHAR(120) NOT NULL,
    email           VARCHAR(160) UNIQUE NOT NULL,
    password_hash   TEXT NOT NULL,
    role            user_role NOT NULL DEFAULT 'sales_agent',
    phone           VARCHAR(30),
    active          BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ DEFAULT now(),
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE refresh_tokens (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash      TEXT NOT NULL,
    expires_at      TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Shippers (Customers)
-- ------------------------------------------------------------
CREATE TABLE shippers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(160) NOT NULL,
    email           VARCHAR(160),
    phone           VARCHAR(30),
    billing_address TEXT,
    user_id         UUID REFERENCES users(id),  -- optional shipper-portal login
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Carriers
-- ------------------------------------------------------------
CREATE TABLE carriers (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                VARCHAR(160) NOT NULL,
    mc_number           VARCHAR(30) UNIQUE NOT NULL,
    dot_number          VARCHAR(30) UNIQUE NOT NULL,
    phone               VARCHAR(30),
    email               VARCHAR(160),
    equipment_type      transport_type DEFAULT 'Open',
    insurance_status    VARCHAR(30) DEFAULT 'Active',
    insurance_expiry    DATE,
    w9_uploaded         BOOLEAN DEFAULT FALSE,
    w9_file_url         TEXT,
    coi_uploaded        BOOLEAN DEFAULT FALSE,
    coi_file_url        TEXT,
    performance_score   NUMERIC(2,1) DEFAULT 5.0,
    avg_rate            NUMERIC(10,2) DEFAULT 0,
    active              BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Drivers
-- ------------------------------------------------------------
CREATE TABLE drivers (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    carrier_id      UUID REFERENCES carriers(id) ON DELETE CASCADE,
    name            VARCHAR(120) NOT NULL,
    phone           VARCHAR(30),
    truck_number    VARCHAR(30),
    trailer_type    transport_type DEFAULT 'Open',
    availability    driver_availability DEFAULT 'Available',
    current_lat     NUMERIC(9,6),
    current_lng     NUMERIC(9,6),
    location_label  VARCHAR(120),
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Orders (Loads)
-- ------------------------------------------------------------
CREATE TABLE orders (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number        VARCHAR(20) UNIQUE NOT NULL,           -- e.g. EV-10231
    shipper_id          UUID REFERENCES shippers(id),
    carrier_id          UUID REFERENCES carriers(id),
    driver_id           UUID REFERENCES drivers(id),
    dispatcher_id       UUID REFERENCES users(id),

    pickup_contact      VARCHAR(120),
    pickup_phone        VARCHAR(30),
    pickup_address      TEXT,
    pickup_city         VARCHAR(80),
    pickup_state        VARCHAR(10),
    pickup_date         DATE,

    delivery_contact    VARCHAR(120),
    delivery_phone      VARCHAR(30),
    delivery_address    TEXT,
    delivery_city       VARCHAR(80),
    delivery_state      VARCHAR(10),
    delivery_date       DATE,

    vehicle_year        VARCHAR(4),
    vehicle_make        VARCHAR(60),
    vehicle_model       VARCHAR(60),
    vin                 VARCHAR(32),
    lot_number          VARCHAR(40),
    vehicle_condition   vehicle_condition DEFAULT 'Running',
    transport_type      transport_type DEFAULT 'Open',

    customer_pay        NUMERIC(10,2) NOT NULL DEFAULT 0,
    carrier_pay         NUMERIC(10,2) NOT NULL DEFAULT 0,
    deposit             NUMERIC(10,2) DEFAULT 0,
    profit              NUMERIC(10,2) GENERATED ALWAYS AS (customer_pay - carrier_pay) STORED,

    status              order_status NOT NULL DEFAULT 'Available',
    pickup_eta          DATE,
    delivery_eta         DATE,

    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_dispatcher ON orders(dispatcher_id);
CREATE INDEX idx_orders_carrier ON orders(carrier_id);
CREATE INDEX idx_orders_shipper ON orders(shipper_id);

-- ------------------------------------------------------------
-- Order Status History (audit trail for dispatch board)
-- ------------------------------------------------------------
CREATE TABLE order_status_history (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    from_status     order_status,
    to_status       order_status NOT NULL,
    changed_by      UUID REFERENCES users(id),
    changed_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Documents
-- ------------------------------------------------------------
CREATE TABLE documents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    doc_type        doc_type NOT NULL,
    file_url        TEXT,
    signed          BOOLEAN DEFAULT FALSE,
    signed_by       VARCHAR(120),
    signed_at       TIMESTAMPTZ,
    generated_at    TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Invoices (customer billing)
-- ------------------------------------------------------------
CREATE TABLE invoices (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number  VARCHAR(20) UNIQUE NOT NULL,
    order_id        UUID NOT NULL REFERENCES orders(id),
    shipper_id      UUID REFERENCES shippers(id),
    amount          NUMERIC(10,2) NOT NULL,
    status          payment_status DEFAULT 'Unpaid',
    method          VARCHAR(30),
    due_date        DATE,
    paid_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Carrier Payments (payouts)
-- ------------------------------------------------------------
CREATE TABLE carrier_payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payment_number  VARCHAR(20) UNIQUE NOT NULL,
    order_id        UUID NOT NULL REFERENCES orders(id),
    carrier_id      UUID REFERENCES carriers(id),
    amount          NUMERIC(10,2) NOT NULL,
    status          payment_status DEFAULT 'Unpaid',
    method          VARCHAR(30),
    paid_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Team Goals
-- ------------------------------------------------------------
CREATE TABLE team_goals (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    period_start    DATE NOT NULL,
    period_end      DATE NOT NULL,
    target_amount   NUMERIC(10,2) NOT NULL,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Notifications
-- ------------------------------------------------------------
CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID REFERENCES users(id) ON DELETE CASCADE,
    message         TEXT NOT NULL,
    read            BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMPTZ DEFAULT now()
);

-- ------------------------------------------------------------
-- Views used by Dashboard & Reports
-- ------------------------------------------------------------
CREATE VIEW v_order_financials AS
SELECT
    o.id, o.order_number, o.status, o.dispatcher_id, o.carrier_id, o.shipper_id,
    o.customer_pay, o.carrier_pay, o.profit, o.pickup_date, o.delivery_date
FROM orders o
WHERE o.status <> 'Cancelled';

CREATE VIEW v_dispatcher_performance AS
SELECT
    u.id AS dispatcher_id, u.full_name,
    COUNT(o.id) AS orders_booked,
    COALESCE(SUM(o.customer_pay), 0) AS revenue,
    COALESCE(SUM(o.carrier_pay), 0) AS carrier_pay,
    COALESCE(SUM(o.profit), 0) AS profit
FROM users u
LEFT JOIN orders o ON o.dispatcher_id = u.id AND o.status <> 'Cancelled'
WHERE u.role = 'sales_agent' OR u.role = 'dispatcher'
GROUP BY u.id, u.full_name;
