-- ============================================================
--  Eminent Ventures — Seed Data
--  Run after schema.sql
-- ============================================================

-- Users (password for all demo accounts: "Passw0rd!" — bcrypt hash placeholder)
INSERT INTO users (full_name, email, password_hash, role) VALUES
('Admin User',   'admin@eminentventures.com',      '$2b$10$replaceWithRealBcryptHash', 'admin'),
('Jack Ridley',  'jack@eminentventures.com',       '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Zack Turner',  'zack@eminentventures.com',       '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Peter Nolan',  'peter@eminentventures.com',      '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Emma Sato',    'emma@eminentventures.com',       '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Henry Brooks', 'henry@eminentventures.com',      '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Jason Kwan',   'jason@eminentventures.com',      '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Mark Delacroix','mark@eminentventures.com',      '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Dexter Voss',  'dexter@eminentventures.com',     '$2b$10$replaceWithRealBcryptHash', 'sales_agent'),
('Dispatch Desk','dispatch@eminentventures.com',   '$2b$10$replaceWithRealBcryptHash', 'dispatcher'),
('Demo Shipper', 'shipper@eminentventures.com',    '$2b$10$replaceWithRealBcryptHash', 'shipper');

-- Shippers
INSERT INTO shippers (name, email, phone, billing_address) VALUES
('R. Alvarez',    'r.alvarez@example.com',    '(214) 555-0110', '4021 Maple Ave, Dallas, TX'),
('T. Nguyen',     't.nguyen@example.com',     '(305) 555-0122', '118 Ocean Dr, Miami, FL'),
('M. Carter',     'm.carter@example.com',     '(213) 555-0134', '900 Sunset Blvd, Los Angeles, CA'),
('S. Bianchi',    's.bianchi@example.com',    '(614) 555-0146', '55 High St, Columbus, OH'),
('J. Whitfield',  'j.whitfield@example.com',  '(973) 555-0158', '210 Market St, Newark, NJ'),
('K. Osei',       'k.osei@example.com',       '(206) 555-0170', '77 Pine St, Seattle, WA'),
('D. Park',       'd.park@example.com',       '(713) 555-0182', '340 Main St, Houston, TX'),
('L. Fontaine',   'l.fontaine@example.com',   '(704) 555-0194', '12 Trade St, Charlotte, NC');

-- Carriers
INSERT INTO carriers (name, mc_number, dot_number, phone, equipment_type, insurance_status, w9_uploaded, coi_uploaded, performance_score, avg_rate) VALUES
('Silver Arrow Logistics',  'MC-712041', 'DOT-2210077', '(800) 555-0111', 'Open',     'Active',         TRUE,  TRUE,  4.6, 945),
('Bluegrass Auto Haulers',  'MC-712082', 'DOT-2210154', '(800) 555-0112', 'Open',     'Active',         FALSE, TRUE,  4.3, 990),
('Redline Transport Co',    'MC-712123', 'DOT-2210231', '(800) 555-0113', 'Enclosed', 'Active',         TRUE,  TRUE,  4.8, 1140),
('Summit Ridge Carriers',   'MC-712164', 'DOT-2210308', '(800) 555-0114', 'Open',     'Expiring Soon',  TRUE,  FALSE, 4.1, 900),
('Pacific Crest Hauling',   'MC-712205', 'DOT-2210385', '(800) 555-0115', 'Open',     'Active',         TRUE,  TRUE,  4.4, 960),
('Ironhide Freight',        'MC-712246', 'DOT-2210462', '(800) 555-0116', 'Enclosed', 'Active',         FALSE, TRUE,  4.7, 1200),
('Cascade Auto Movers',     'MC-712287', 'DOT-2210539', '(800) 555-0117', 'Open',     'Active',         TRUE,  TRUE,  4.2, 915),
('Sunbelt Transport LLC',   'MC-712328', 'DOT-2210616', '(800) 555-0118', 'Open',     'Active',         TRUE,  TRUE,  4.5, 975);

-- Drivers (linked to carriers by order of insertion)
INSERT INTO drivers (carrier_id, name, phone, truck_number, trailer_type, availability, location_label)
SELECT c.id, d.name, d.phone, d.truck, d.trailer::transport_type, d.avail::driver_availability, d.loc
FROM (VALUES
    ('Marcus Reyes',   '(619) 555-0210', 'TRK-310', 'Open',     'Available', 'Dallas, TX'),
    ('Elena Novak',    '(619) 555-0211', 'TRK-311', 'Open',     'On Route',  'Miami, FL'),
    ('Trevor Bishop',  '(619) 555-0212', 'Enclosed', 'Enclosed','Off Duty',  'Los Angeles, CA'),
    ('Priya Adeyemi',  '(619) 555-0213', 'TRK-313', 'Open',     'Available', 'Columbus, OH'),
    ('Dominic Cross',  '(619) 555-0214', 'TRK-314', 'Open',     'On Route',  'Newark, NJ'),
    ('Sasha Duval',    '(619) 555-0215', 'TRK-315', 'Enclosed', 'Available', 'Seattle, WA'),
    ('Ola Reyes',      '(619) 555-0216', 'TRK-316', 'Open',     'Off Duty',  'Houston, TX'),
    ('Ruben Novak',    '(619) 555-0217', 'TRK-317', 'Open',     'On Route',  'Charlotte, NC')
) AS d(name, phone, truck, trailer, avail, loc)
JOIN carriers c ON c.name = (ARRAY['Silver Arrow Logistics','Bluegrass Auto Haulers','Redline Transport Co',
    'Summit Ridge Carriers','Pacific Crest Hauling','Ironhide Freight','Cascade Auto Movers','Sunbelt Transport LLC'])
    [1 + (ROW_NUMBER() OVER () - 1) % 8];

-- Team goal
INSERT INTO team_goals (period_start, period_end, target_amount) VALUES
('2026-07-15', '2026-08-14', 13000.00);

-- Sample orders (a handful of representative rows — extend as needed)
INSERT INTO orders (
    order_number, shipper_id, carrier_id, dispatcher_id,
    pickup_contact, pickup_phone, pickup_address, pickup_city, pickup_state, pickup_date,
    delivery_contact, delivery_phone, delivery_address, delivery_city, delivery_state, delivery_date,
    vehicle_year, vehicle_make, vehicle_model, vin, lot_number, vehicle_condition, transport_type,
    customer_pay, carrier_pay, deposit, status
)
SELECT
    'EV-1' || (10230 + n)::text,
    (SELECT id FROM shippers ORDER BY random() LIMIT 1),
    CASE WHEN n % 6 = 0 THEN NULL ELSE (SELECT id FROM carriers ORDER BY random() LIMIT 1) END,
    (SELECT id FROM users WHERE role = 'sales_agent' ORDER BY random() LIMIT 1),
    'Contact ' || n, '(555) 555-01' || LPAD(n::text, 2, '0'), n || ' Depot Rd', 'Dallas', 'TX', CURRENT_DATE + (n % 10),
    'Contact D' || n, '(555) 555-02' || LPAD(n::text, 2, '0'), n || ' Delivery Ave', 'Chicago', 'IL', CURRENT_DATE + (n % 10) + 4,
    (2016 + n % 8)::text, 'Toyota', 'Camry', 'VIN' || LPAD(n::text, 10, '0'), 'LOT-' || n,
    CASE WHEN n % 6 = 0 THEN 'Inoperable' ELSE 'Running' END::vehicle_condition,
    CASE WHEN n % 3 = 0 THEN 'Enclosed' ELSE 'Open' END::transport_type,
    600 + (n * 37) % 900,
    (600 + (n * 37) % 900) * 0.78,
    (600 + (n * 37) % 900) * 0.2,
    (ARRAY['Available','Assigned','Picked Up','In Transit','Delivered','Cancelled'])[1 + n % 6]::order_status
FROM generate_series(1, 40) AS n;
