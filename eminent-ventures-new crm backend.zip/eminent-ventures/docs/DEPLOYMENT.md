# Deployment Guide — Eminent Ventures TMS

## 1. Generate real password hashes before going live

`database/seed.sql` ships with placeholder password hashes. Replace them:

```bash
node -e "console.log(require('bcryptjs').hashSync('YourRealPassword!', 10))"
```

Paste the output into the `password_hash` column for each seeded user, or
register users via `POST /api/auth/register` after the schema is deployed.

## 2. Database (PostgreSQL)

Any managed Postgres works: **Render**, **Railway**, **Supabase**, **Neon**,
or **AWS RDS**.

```bash
# Example: Render Postgres, Railway Postgres, or Neon
psql "$DATABASE_URL" -f database/schema.sql
psql "$DATABASE_URL" -f database/seed.sql
```

Keep `DATABASE_URL` handy — the backend needs it.

## 3. Backend API

### Option A — Render / Railway (simplest)

1. Push this repo to GitHub.
2. Create a new **Web Service**, root directory `backend/`.
3. Build command: `npm install`
4. Start command: `npm start`
5. Environment variables:
   - `DATABASE_URL` — from step 2
   - `DATABASE_SSL` — `true` for most managed Postgres providers
   - `JWT_SECRET` — a long random string (`openssl rand -hex 32`)
   - `CORS_ORIGIN` — your frontend's deployed URL
   - `PORT` — usually auto-set by the platform

### Option B — Docker

```dockerfile
# backend/Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install --production
COPY . .
EXPOSE 4000
CMD ["node", "src/server.js"]
```

```bash
docker build -t eminent-ventures-api ./backend
docker run -p 4000:4000 --env-file backend/.env eminent-ventures-api
```

## 4. Frontend

The dashboard/orders/dispatch UI can be deployed as a static React build to
**Vercel**, **Netlify**, or **Cloudflare Pages**.

1. Set the API base URL as an environment variable, e.g. `VITE_API_URL` or
   `REACT_APP_API_URL`, pointing at your deployed backend
   (`https://api.eminentventures.com/api`).
2. `npm run build`
3. Deploy the `dist/` (Vite) or `build/` (CRA) folder.

## 5. Post-deploy checklist

- [ ] Rotate `JWT_SECRET` away from any development value
- [ ] Confirm `CORS_ORIGIN` matches the live frontend domain exactly
- [ ] Enable automated Postgres backups (daily, 7-day retention minimum)
- [ ] Set up HTTPS (most platforms above do this automatically)
- [ ] Load-test the `/api/orders` and `/api/reports/summary` endpoints if
      dealership volume is high
- [ ] Configure a real object storage bucket (S3 / Cloudflare R2) for
      uploaded W-9s, COIs, and signed documents instead of local disk

## 6. Environment variable reference

| Variable | Where | Purpose |
|---|---|---|
| `DATABASE_URL` | backend | Postgres connection string |
| `DATABASE_SSL` | backend | `true`/`false`, required by most managed DBs |
| `JWT_SECRET` | backend | Signs and verifies auth tokens |
| `CORS_ORIGIN` | backend | Restricts which frontend origin can call the API |
| `PORT` | backend | API listen port (platform-assigned in most cases) |
| `VITE_API_URL` / `REACT_APP_API_URL` | frontend | Backend base URL the UI calls |
