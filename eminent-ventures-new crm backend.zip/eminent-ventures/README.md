# Eminent Ventures — Broker/Shipper TMS

A complete auto-transport Broker/Shipper Transport Management System, built for Eminent Ventures.

## What's included

```
eminent-ventures/
├── EminentVenturesTMS.jsx      (delivered separately as an interactive artifact)
├── backend/                    Express REST API
│   └── src/
│       ├── routes/             orders, dispatch/assign, carriers, drivers,
│       │                       shippers, documents, invoices, payments,
│       │                       reports, team, auth
│       ├── middleware/auth.js  JWT auth + role-based access control
│       ├── db/pool.js          Postgres connection pool
│       └── server.js           App entry point
├── database/
│   ├── schema.sql               Full Postgres schema (13 tables + 2 views)
│   └── seed.sql                 Demo data: users, shippers, carriers, drivers, orders
└── docs/
    └── DEPLOYMENT.md             Step-by-step deployment guide
```

The interactive frontend (dashboard, orders, dispatch board, carriers, drivers,
documents, invoices, payments, reports, team) was delivered as a standalone
React artifact so it can be used immediately. This package contains the
production backend, schema, and seed data that would sit behind it.

## Architecture

- **Frontend**: React (dashboard/orders/dispatch/etc.) — talks to the API over
  `fetch`/JSON using a bearer JWT.
- **Backend**: Node.js + Express, PostgreSQL via `pg`, JWT auth with
  role-based middleware (`admin`, `dispatcher`, `sales_agent`, `shipper`).
- **Database**: PostgreSQL. `profit` is a generated column
  (`customer_pay - carrier_pay`) so it's always correct at the data layer, not
  just in the UI.

## Roles

| Role | Access |
|---|---|
| Admin | Full access to every module |
| Dispatcher | Orders, dispatch board, carriers, drivers, documents |
| Sales Agent | Create orders, view own performance in Team |
| Shipper | View/track their own orders only (read-only) |

## Local setup (quick start)

```bash
# 1. Database
createdb eminent_ventures
psql eminent_ventures -f database/schema.sql
psql eminent_ventures -f database/seed.sql
# NOTE: replace the placeholder password hashes in seed.sql with real
# bcrypt hashes before using any seeded login (see docs/DEPLOYMENT.md)

# 2. Backend
cd backend
cp .env.example .env    # fill in DATABASE_URL and JWT_SECRET
npm install
npm run dev             # http://localhost:4000

# 3. Frontend
# Point the React app's API base URL at http://localhost:4000/api
```

See `docs/DEPLOYMENT.md` for production deployment (Render/Railway + Vercel,
Docker, and environment variable reference).
